package diseasePredictor;
import com.vaadin.server.Page;
import com.vaadin.ui.themes.Reindeer;

import java.sql.SQLException;

import org.vaadin.dialogs.ConfirmDialog;

import com.vaadin.annotations.PreserveOnRefresh;
import com.vaadin.data.Property;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.util.filter.Compare;
import com.vaadin.data.util.sqlcontainer.SQLContainer;
import com.vaadin.data.util.sqlcontainer.query.QueryDelegate;
import com.vaadin.data.util.sqlcontainer.query.QueryDelegate.RowIdChangeEvent;
import com.vaadin.event.ItemClickEvent;
import com.vaadin.event.ShortcutListener;
import com.vaadin.event.ItemClickEvent.ItemClickListener;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Notification;
import com.vaadin.ui.OptionGroup;
import com.vaadin.ui.TabSheet;
import com.vaadin.ui.UI;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.VerticalSplitPanel;
/*
 * This is the Patient Dashboard view class which creates a view with patient data and also provides a feature to edit the patient's profile
 */
@SuppressWarnings("serial")
@PreserveOnRefresh
public class PatientView  extends VerticalSplitPanel implements View,ItemClickListener, QueryDelegate.RowIdChangeListener {
	  public String username;	 
	  private PatientList patientList= null;
	  public String psex=null;
	  public String pstatus=null;
	  final DatabaseHelper dbHelp = new DatabaseHelper();
	  public PatientView() {	
        }        
	
	@Override
    public void enter(ViewChangeEvent event) {
				
		this.username = String.valueOf(getSession().getAttribute("user"));
		/*
		 * The PatientList class is instantiated here to create a table with list of patients under  the current user
		 */
		patientList = new PatientList(this);
		
		addStyleName("login-panel");
		setFirstComponent(patientList);
		/*
		 * patientList.fixVisibleAndSelectedItem() is called  from the Patientlist class 
		 * to enable click function to display the details 
		 * of the selected patient and enabling the edit feature for that patient
		 */
        patientList.fixVisibleAndSelectedItem();
       
    }
	
	/*
	 * itemClick(ItemClickEvent event) defines all the feature after the patient is selected from the table view
	 */
	
	@Override
	public void itemClick(ItemClickEvent event) {
		
		String patientID=event.getItemId().toString();
		int id=Integer.parseInt(patientID);
		TabSheet tabsheet = new TabSheet();
       	tabsheet.setSizeFull();
		tabsheet.addStyleName(Reindeer.LAYOUT_WHITE);
		tabsheet.addStyleName(Reindeer.WINDOW_BLACK);
		HorizontalLayout DisplayLayout=new HorizontalLayout();
		VerticalLayout display=new VerticalLayout();
		final DatabaseHelper dbHelp1 = new DatabaseHelper();
		dbHelp1.getPatientContainer().removeAllContainerFilters();
		final SQLContainer patientDisplaydata=dbHelp1.getPatientContainer();
		patientDisplaydata.addContainerFilter(new Compare.Equal ("patient_ID",id));
		final Object itemId=patientDisplaydata.firstItemId();
		String name=patientDisplaydata.getItem(itemId).getItemProperty("patient_Name").getValue().toString();
		String sex=patientDisplaydata.getItem(itemId).getItemProperty("Sex").getValue().toString();
		if (sex.equals("M")){
			sex="Male";
		}
		else{
			sex="Female";
		}
		String age=patientDisplaydata.getItem(itemId).getItemProperty("patient_Age").getValue().toString();
		String address=patientDisplaydata.getItem(itemId).getItemProperty("patient_Address").getValue().toString();
		String ph=patientDisplaydata.getItem(itemId).getItemProperty("patient_PhNo").getValue().toString();
		String BloodPressure=patientDisplaydata.getItem(itemId).getItemProperty("BloodPressure").getValue().toString();
		String BloodSugarLevel=patientDisplaydata.getItem(itemId).getItemProperty("BloodSugarLevel").getValue().toString();
		String BodyTemperature=patientDisplaydata.getItem(itemId).getItemProperty("BodyTemperature").getValue().toString();
		String ColesterolLevel=patientDisplaydata.getItem(itemId).getItemProperty("ColesterolLevel").getValue().toString();
		String status=patientDisplaydata.getItem(itemId).getItemProperty("status").getValue().toString();
		com.vaadin.ui.Label l=new com.vaadin.ui.Label("Details of the selected patient");
		l.addStyleName("h2");
		com.vaadin.ui.Label lname=new com.vaadin.ui.Label("Name: "+ name);
		com.vaadin.ui.Label lsex=new com.vaadin.ui.Label("Sex: "+ sex);
		com.vaadin.ui.Label lage=new com.vaadin.ui.Label("Age: "+ age);
		com.vaadin.ui.Label laddress=new com.vaadin.ui.Label("Address: "+ address);
		com.vaadin.ui.Label lph=new com.vaadin.ui.Label("Phone Number: "+ ph);
		com.vaadin.ui.Label lBloodPressure=new com.vaadin.ui.Label("Blood Pressure(mmHg-systolic): "+  BloodPressure);
		com.vaadin.ui.Label lBloodSugarLevel=new com.vaadin.ui.Label("Blood Sugar level(mmol/L): "+ BloodSugarLevel);
		com.vaadin.ui.Label lBodyTemperature=new com.vaadin.ui.Label("Body temperature( degree F): "+ BodyTemperature);
		com.vaadin.ui.Label lColesterolLevel=new com.vaadin.ui.Label("Colesterol level(%): "+ ColesterolLevel);
		com.vaadin.ui.Label lstatus=new com.vaadin.ui.Label("Status: "+ status);
		display.addStyleName("h4");
		display.addComponent(l);
		display.addComponent(lname);
		display.addComponent(lage);
		display.addComponent(lsex);
		display.addComponent(laddress);
		display.addComponent(lph);
		display.addComponent(lBloodPressure);
		display.addComponent(lBloodSugarLevel);
		display.addComponent(lBodyTemperature);
		display.addComponent(lColesterolLevel);
		display.addComponent(lstatus);
		DisplayLayout.addComponent(display);
		DisplayLayout.setComponentAlignment(display, Alignment.MIDDLE_CENTER);
		VerticalLayout editDisplay=new VerticalLayout();
		FormLayout editForm=new FormLayout();
		com.vaadin.ui.Label lp=new com.vaadin.ui.Label("Edit the selected patient's Data");
		lp.addStyleName("h2");
		final TextField tname=new TextField("Name:");
		tname.setValue(name);
		final OptionGroup p_sex= new OptionGroup("Sex:");
		p_sex.setMultiSelect(false);
		p_sex.addItem("Male");
		p_sex.addItem("Female");
		
		p_sex.addValueChangeListener(new Property.ValueChangeListener() {
            private static final long serialVersionUID = -6857112166321059475L;

            public void valueChange(ValueChangeEvent event) {
                String value = (String) event.getProperty().getValue();
                if(value=="Male"){
                	psex="M";
                }
                else{
                	psex="F";	
                }
            }
        });
		p_sex.setImmediate(true);;
		
	
			
		final TextField tage=new TextField("Age:");
		tage.setValue(age);
		final TextField tladdress=new TextField("Address:");
		tladdress.setValue(address);
		final TextField tph=new TextField("Phone Number(Only Numbers):");
		tph.setValue(ph);
		final TextField tBloodPressure=new TextField("Blood Pressure(mmHg-systolic):");
		tBloodPressure.setValue(BloodPressure);
		final TextField tBloodSugarLevel=new TextField("Blood Sugar level(mmol/L:");
		tBloodSugarLevel.setValue(BloodSugarLevel);
		final TextField tBodyTemperature=new TextField("Body temperature( degree F):");
		tBodyTemperature.setValue(BodyTemperature);
		final TextField tColesterolLevel=new TextField("Colesterol level(%):");
		tColesterolLevel.setValue(ColesterolLevel);
		
		final OptionGroup tstatus= new OptionGroup("Status:");
		tstatus.setMultiSelect(false);
		tstatus.addItem("Alive");
		tstatus.addItem("Dead");
		
		tstatus.addValueChangeListener(new Property.ValueChangeListener() {
            private static final long serialVersionUID = -6857112166321059475L;

            public void valueChange(ValueChangeEvent event) {
            	pstatus = (String) event.getProperty().getValue();
            }
        });
		final Button save=new Button("Save");
		final ShortcutListener entersave = new ShortcutListener("Save",
	                KeyCode.ENTER, null) {
	            @Override
	            public void handleAction(Object sender, Object target) {
	               save.click();
	            }
	    };
	    save.addClickListener(new ClickListener() {
	        	
	            @Override
	            public void buttonClick(ClickEvent event) {
	            	ConfirmDialog.show(UI.getCurrent(), "Please Confirm:", "To save the data",
	            	        "Yes", "No", new ConfirmDialog.Listener() {

	            	            @SuppressWarnings("unchecked")
								public void onClose(ConfirmDialog dialog) {
	            	                if (dialog.isConfirmed()) {
	            	                    // Confirmed to continue
	            	                	
	            	                	int p_age = Integer.parseInt(tage.getValue());
	            	                	int p_ph = Integer.parseInt(tph.getValue());
	            	                	int p_bloodPressure = Integer.parseInt(tBloodPressure.getValue());
	            	                	int p_bloodsugar = Integer.parseInt(tBloodSugarLevel.getValue());
	            	                	int p_temp = Integer.parseInt(tBodyTemperature.getValue());
	            	                	int p_col = Integer.parseInt(tColesterolLevel.getValue());
	            	                	patientDisplaydata.getItem(itemId).getItemProperty("patient_Name").setValue(tname.getValue());
	            	                	if (psex!= null){
	            	                		patientDisplaydata.getItem(itemId).getItemProperty("Sex").setValue(psex);
	            	                	}else{
	            	                		
	            	                	}
	            	                	patientDisplaydata.getItem(itemId).getItemProperty("patient_Age").setValue(p_age);
  	            	            		patientDisplaydata.getItem(itemId).getItemProperty("patient_Address").setValue(tladdress.getValue());
  	            	            		patientDisplaydata.getItem(itemId).getItemProperty("patient_PhNo").setValue(p_ph);
  	            	            		patientDisplaydata.getItem(itemId).getItemProperty("BloodPressure").setValue(p_bloodPressure);
  	            	            		patientDisplaydata.getItem(itemId).getItemProperty("BloodSugarLevel").setValue(p_bloodsugar);
  	            	            		patientDisplaydata.getItem(itemId).getItemProperty("BodyTemperature").setValue(p_temp);
  	            	            		patientDisplaydata.getItem(itemId).getItemProperty("ColesterolLevel").setValue(p_col);
  	            	            		if(pstatus!=null){
  	            	            		patientDisplaydata.getItem(itemId).getItemProperty("status").setValue(pstatus);
  	            	            		}else{
  	            	            			
  	            	            		}
  	            	                	try {
  											patientDisplaydata.commit();
  											Notification.show("The Patient Profile Updated");
  		            	          			getUI().getNavigator().addView("/Patient Dashboard",PatientView.class);
  		            	          			getUI().getNavigator().navigateTo("/Patient Dashboard");
  											
  										} catch (UnsupportedOperationException e) {
  											Notification notif=new Notification("Error","<br/>Invalid!!",
		            	          				    Notification.Type.ERROR_MESSAGE, true);
		            	          			notif.show(Page.getCurrent());
  											e.printStackTrace();
  										} catch (SQLException e) {
  											Notification notif=new Notification("Error","<br/>Invalid Data",
		            	          				    Notification.Type.ERROR_MESSAGE, true);
		            	          			notif.show(Page.getCurrent());
  											e.printStackTrace();
  										}
	            	                	
	            	                	
	            	            }
	            	                else{
	            	                	
	            	                }
	            	            }
	            	        });
	            	
	            }
	    });
	    save.addShortcutListener(entersave);
		editDisplay.addComponent(lp);
		editForm.addComponent(tname);
		editForm.addComponent(p_sex);
		editForm.addComponent(tage);
		editForm.addComponent(tladdress);
		editForm.addComponent(tph);
		editForm.addComponent(tBloodPressure);
		editForm.addComponent(tBloodSugarLevel);
		editForm.addComponent(tBodyTemperature);
		editForm.addComponent(tColesterolLevel);
		editForm.addComponent(tstatus);
		editForm.addComponent(save);
		editDisplay.addComponent(editForm);
		tabsheet.addStyleName("tabs");
		tabsheet.addTab(DisplayLayout,
               "Detail view",
               null);
		tabsheet.addTab(editDisplay,
               "Edit",
               null);
     		
		
		setSecondComponent(tabsheet);
    }
	
	public DatabaseHelper getdbHelp(){
		return dbHelp;
	}
	@Override
	public void rowIdChange(RowIdChangeEvent event) {
		patientList.select(event.getNewRowId());
		patientList.fixVisibleAndSelectedItem();
	}
		
	
	
}
