package diseasePredictor;


import com.vaadin.data.util.filter.Compare;
import com.vaadin.event.ItemClickEvent.ItemClickListener;
import com.vaadin.ui.Table;

public class PatientList  extends Table{

	/**
	 * Generate a list of Patients records corresponding to the current user
	 */
	private static final long serialVersionUID = 1907599382721090890L;
	

	public PatientList(final PatientView app){
		
		 
		 int UID= Integer.parseInt(app.username);
		 setSizeFull();
		 app.getdbHelp().getPatientContainer().removeAllContainerFilters();
		 app.getdbHelp().getPatientContainer().addContainerFilter(new Compare.Equal ("doctor_ID",UID));
		 setContainerDataSource(app.getdbHelp().getPatientContainer());
		 setColumnCollapsingAllowed(true);
		 setColumnReorderingAllowed(true);
		 setSelectable(true);
	     setImmediate(true);
	     addItemClickListener((ItemClickListener) app);
	     setNullSelectionAllowed(false);
	     setVisibleColumns(DatabaseHelper.NATURAL_COL_ORDER);
	     setColumnHeaders(DatabaseHelper.COL_HEADERS_ENGLISH);
	     
		
	}
	public void fixVisibleAndSelectedItem() {
        if ((getValue() == null || !containsId(getValue())) && size() > 0) {
            Object itemId = getItemIds().iterator().next();
            select(itemId);
            setCurrentPageFirstItemId(itemId);
        } else {
            setCurrentPageFirstItemId(getValue());
        }
    }
	

}
