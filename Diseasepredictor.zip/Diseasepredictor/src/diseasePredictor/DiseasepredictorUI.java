
/*
 * Author: Sushri Sunita Purohit
 * About: Disease Prediction web Application developed using Vaadin framework
 * Description: First view is a login view for authentication to use the application
 * 
 */
package diseasePredictor;
/*
 * Imports Section
 */
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import javax.servlet.annotation.WebServlet;
import diseasePredictor.DatabaseHelper;
import org.vaadin.dialogs.ConfirmDialog;
import com.vaadin.annotations.PreserveOnRefresh;
import com.vaadin.annotations.Theme;
import com.vaadin.annotations.VaadinServletConfiguration;
import com.vaadin.data.util.filter.And;
import com.vaadin.data.util.filter.Compare;
import com.vaadin.data.util.sqlcontainer.SQLContainer;
import com.vaadin.data.util.sqlcontainer.connection.JDBCConnectionPool;
import com.vaadin.data.util.sqlcontainer.query.FreeformQuery;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.event.ShortcutListener;
import com.vaadin.navigator.Navigator;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.server.Page;
import com.vaadin.server.ThemeResource;
import com.vaadin.server.VaadinRequest;
import com.vaadin.server.VaadinServlet;
import com.vaadin.shared.ui.label.ContentMode;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.Component;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.DragAndDropWrapper;
import com.vaadin.ui.Flash;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Image;
import com.vaadin.ui.Label;
import com.vaadin.ui.MenuBar;
import com.vaadin.ui.Panel;
import com.vaadin.ui.MenuBar.Command;
import com.vaadin.ui.MenuBar.MenuItem;
import com.vaadin.ui.NativeButton;
import com.vaadin.ui.Notification;
import com.vaadin.ui.PasswordField;
import com.vaadin.ui.TextField;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;

import de.steinwedel.messagebox.ButtonId;
import de.steinwedel.messagebox.Icon;
import de.steinwedel.messagebox.MessageBox;
/*
 * The main User interface class is DiseasepredictorUI  which is based on the diseasepredictor theme
 */
@SuppressWarnings("serial")
@PreserveOnRefresh
@Theme("diseasepredictor")
public class DiseasepredictorUI extends UI{
	@WebServlet(value = "/*", asyncSupported = true)
	@VaadinServletConfiguration(productionMode = false, ui = DiseasepredictorUI.class, widgetset = "diseasePredictor.widgetset.DiseasepredictorWidgetset")
	
	public static class Servlet extends VaadinServlet {
	}
	CssLayout root = new CssLayout();
	VerticalLayout loginLayout;
	VerticalLayout RegisterLayout;
	CssLayout menu = new CssLayout();
    CssLayout content = new CssLayout();
    //Hashmap for different views
    HashMap<String, Class<? extends View>> routes = new HashMap<String, Class<? extends View>>() {
        {
            put("/Create Patient Profile",CreatePatient.class);
            put("/Home Page",HomePage.class);
            put("/Run Diagnosis",RunDiagnosis.class);
            put("/Patient Dashboard",PatientView.class);
        }
    };
    HashMap<String, Button> viewNameToMenuButton = new HashMap<String, Button>();
    private Navigator nav;
    protected static final String MAINVIEW = "HomePage";
    private  String Uname=null;
    private String name=null;
    final DatabaseHelper dbHelp = new DatabaseHelper();
	@Override
	protected void init(VaadinRequest request) {
		setLocale(Locale.US);
		setContent(root);
        root.addStyleName("root");
        root.setSizeFull();
        Label bg = new Label();
        bg.setSizeUndefined();
        bg.addStyleName("login-bg");
        root.addComponent(bg);
        Uname=buildLoginView(false);
			}
	/*Function to build the login page
	 * 
	 * Contains login feature also have the feature of registering new user
	 */
	private String buildLoginView(boolean exit) {
		
		if (exit) {
            root.removeAllComponents();
        }       
		addStyleName("login");
		loginLayout = new VerticalLayout();
        loginLayout.setSizeFull();
        loginLayout.addStyleName("login-layout");
        root.addComponent(loginLayout);
        //create a login panel in the window
        final CssLayout loginPanel = new CssLayout();
        loginPanel.addStyleName("login-panel");
        
        HorizontalLayout labels = new HorizontalLayout();
        labels.setWidth("100%");
        labels.setMargin(true);
        labels.addStyleName("labels");
        loginPanel.addComponent(labels);
        Flash flash = new Flash(null,
			    new ThemeResource("img/login.jpg"));
        labels.addComponent(flash);
        Label welcome = new Label(" Welcome to Health Predictor");
        
        welcome.setSizeUndefined();
        welcome.addStyleName("h2");
        labels.addComponent(welcome);
        labels.addComponent(welcome);
        labels.setComponentAlignment(welcome, Alignment.MIDDLE_LEFT);
        // creates a horizontal layout for login fields
        HorizontalLayout fields = new HorizontalLayout();
        fields.setSpacing(true);
        fields.setMargin(true);
        fields.addStyleName("fields");
        //username textfield 
        final TextField username = new TextField("User ID");
        username.focus();
        fields.addComponent(username);
        //password testfield
        final PasswordField password = new PasswordField("Password");
        fields.addComponent(password);
        // signin button
        final Button signin = new Button("Sign In");
        signin.addStyleName("default");
        fields.addComponent(signin);
        fields.setComponentAlignment(signin, Alignment.BOTTOM_LEFT);
        //Register button
        final Button register = new Button("Register");
        register.addStyleName("default");
        fields.addComponent(register);
        fields.setComponentAlignment(register, Alignment.BOTTOM_LEFT);
                    
        final ShortcutListener enter = new ShortcutListener("Sign In",
                KeyCode.ENTER, null) {
            @Override
            public void handleAction(Object sender, Object target) {
                signin.click();
            }
        };
        final ShortcutListener enter1 = new ShortcutListener("Register",
                KeyCode.ENTER, null) {
            @Override
            public void handleAction(Object sender, Object target) {
                register.click();
            }
        };
                
        signin.addClickListener(new ClickListener() {          
			@Override
            public void buttonClick(ClickEvent event) {
            	
            	if ((username.getValue() != null && password.getValue() != null) || (username.getValue() != null || password.getValue() != null) || 
            		(username.getValue() != "" && password.getValue() != "")|| (username.getValue() != "" || password.getValue() != ""))
            	{
            	String Uname= username.getValue();
            	String pwd=password.getValue();
            	int check=authenticateUser(Uname,pwd);
            	
            	    if(check!=0){ 
            		signin.removeShortcutListener(enter);
            		getSession().setAttribute("user", Uname);
                    buildMainView(Uname);
            	}
                    else{
                    	if (loginPanel.getComponentCount() > 2) {
                            // Remove the previous error message
                            loginPanel.removeComponent(loginPanel.getComponent(2));
                        }
                        // Add new error message
                        Label error = new Label(
                                "Wrong userID or password. <span>Try again</span>",ContentMode.HTML);
                    	//Label error = new Label(
                                //"Wrong username or password. <span>Try again</span>"+ check);
                        error.addStyleName("error");
                        error.setSizeUndefined();
                        error.addStyleName("light");
                        // Add animation
                        error.addStyleName("v-animate-reveal");
                        loginPanel.addComponent(error);
                        username.focus();
                    }
            	}
            	
            	else{
            		if (loginPanel.getComponentCount() > 2) {
                        // Remove the previous error message
                        loginPanel.removeComponent(loginPanel.getComponent(2));
                    }
                    // Add new error message
                    Label error = new Label(
                            "Empty userID or password. <span>Try again</span>",
                            ContentMode.HTML);
                    error.addStyleName("error");
                    error.setSizeUndefined();
                    error.addStyleName("light");
                    // Add animation
                    error.addStyleName("v-animate-reveal");
                    loginPanel.addComponent(error);
                    username.focus();
            	}
                
            	 
            }
            
        });
        
        signin.addShortcutListener(enter);
        register.addClickListener(new ClickListener() {
        	
            @Override
            public void buttonClick(ClickEvent event) {
            	registerNewUser();
             
            }
					            
        });
        
        register.addShortcutListener(enter1);
        loginPanel.addComponent(fields);
        loginLayout.addComponent(loginPanel);
        loginLayout.setComponentAlignment(loginPanel, Alignment.MIDDLE_CENTER);
		return Uname;
    	}
		/*
		 * Function definition for registering new user
		 */
		private void registerNewUser() {
		removeStyleName("login");
        root.removeComponent(loginLayout);
        addStyleName("login");
        RegisterLayout = new VerticalLayout();
       // RegisterLayout.setSizeFull();
        RegisterLayout.addStyleName("login-layout");
        root.addComponent(RegisterLayout);
        final CssLayout registerPanel = new CssLayout();
        registerPanel.addStyleName("login-panel");
        HorizontalLayout labels = new HorizontalLayout();
        labels.setWidth("100%");
        labels.setMargin(true);
        labels.addStyleName("labels");
        registerPanel.addComponent(labels);
        //welcome label
        Label welcome = new Label("Enter your details to register");
        welcome.setSizeUndefined();
        welcome.addStyleName("h2");
        labels.addComponent(welcome);
        labels.setComponentAlignment(welcome, Alignment.TOP_CENTER);
        // creates a horizontal layout for login fields
        FormLayout fields = new FormLayout();
        fields.setSpacing(true);
        fields.setMargin(true);
        fields.addStyleName("fields");
        //username textfield 
        final TextField name = new TextField("Name");
        name.setRequired(true);
        fields.addComponent(name);
        //password testfield
        final PasswordField password = new PasswordField("Password");
        password.setRequired(true);
        fields.addComponent(password);
        final PasswordField cpassword = new PasswordField(" Confirm Password");
        cpassword.setRequired(true);
        fields.addComponent(cpassword);
        final  TextField address = new TextField (" Address");
        address.setRequired(true);
        fields.addComponent(address);
        final TextField  phone = new TextField (" Phone Number");
        phone.setRequired(true);
        fields.addComponent(phone);
        final TextField  speciality = new TextField (" Speciality");
        fields.addComponent(speciality);
        //save button
        HorizontalLayout button=new HorizontalLayout();
        final Button save = new Button("Save");
        save.addStyleName("default");
        fields.addComponent(save);
        final Button cancel = new Button("Cancel");
        cancel.addStyleName("default");
        button.addComponent(save);
        button.setSpacing(true);
        button.addComponent(cancel);
         fields.addComponent(button);
        fields.setComponentAlignment(button, Alignment.BOTTOM_LEFT);
        final ShortcutListener entercancel = new ShortcutListener("Cancel",
                KeyCode.ENTER, null) {
            @Override
            public void handleAction(Object sender, Object target) {
               cancel.click();
            }
        };
              
            cancel.addClickListener(new ClickListener() {
        	
            @Override
            public void buttonClick(ClickEvent event) {  
            	 buildLoginView(true);
            }
            
	});
        final ShortcutListener entersave = new ShortcutListener("Save",
                KeyCode.ENTER, null) {
            @Override
            public void handleAction(Object sender, Object target) {
               save.click();
            }
        };
              
            save.addClickListener(new ClickListener() {
        	
            @Override
            public void buttonClick(ClickEvent event) {
            	
            	try{
            		
       			 	final int ph=Integer.parseInt(phone.getValue());
       			 	String pwd= password.getValue().toString();
       			 	String cpwd= cpassword.getValue().toString();
            	    if(!pwd.equals(cpwd)){
	                	               		
        		    	Notification notif=new Notification("Error","<br/>Password does not match",
        		    										Notification.Type.ERROR_MESSAGE, true);
						notif.setStyleName("Notification");
          				notif.show(Page.getCurrent());
        		     
            	    	 
            	    }else{
     				
     				ConfirmDialog.show(UI.getCurrent(), "Please Confirm:", "Are you really sure?",
                	        "Yes", "No", new ConfirmDialog.Listener() {

                	            @SuppressWarnings("unchecked")
    							public void onClose(ConfirmDialog dialog) {
                	                if (dialog.isConfirmed()) {
                	                	
                	                		
                	                			SQLContainer container= dbHelp.getDoctorContainer();
                	                	        Object id = container.addItem();
                	                			container.getContainerProperty(id,"doctor_name").setValue(name.getValue());
                	                			
                	                			container.getContainerProperty(id,"doctor_phNo").setValue(ph); 
                	                			container.getContainerProperty(id,"doctor_address").setValue(address.getValue());
                	                			
                	                		    	container.getContainerProperty(id,"doctor_pwd").setValue(cpassword.getValue());
                	                		    	if(speciality.getValue()!=null){
                	                		    	container.getContainerProperty(id,"speciality").setValue("General");
                	                		    	}else{
                	                		    		
                	                		    	}
                	                		    	try {
    													container.commit();
    												} catch (UnsupportedOperationException e) {
    													Notification notif=new Notification("Error","<br/>Invalid Data!!",
    								          				    Notification.Type.ERROR_MESSAGE, true);
    								          			notif.show(Page.getCurrent());
    													e.printStackTrace();
    												} catch (SQLException e) {
    													Notification notif=new Notification("Error","<br/>Invalid Data!!",
    								          				    Notification.Type.ERROR_MESSAGE, true);
    								          			notif.show(Page.getCurrent());
    													e.printStackTrace();
    												}
                	                			         	                		    
            	                		    	
                	                	container= dbHelp.getDoctorContainer();
                	                	container.removeAllContainerFilters();
                	                	Object id2 = container.lastItemId();
                	                	String docid=container.getItem(id2).getItemProperty("doctor_ID").getValue().toString();
                	                	MessageBox.showPlain(Icon.INFO, " Welcome"+ " " + name.getValue() + "!  " + "Your UserID is: ", docid, ButtonId.OK);
                	                	buildLoginView(true);
                	                } else {
                	                    // User did not confirm
                	                	buildLoginView(true);
                	                }
                	            }
                	        });
                	
     				
     			}
            	}catch(Exception e){
            	
            		Notification notif=new Notification("Error","<br/>Invalid Data!!",
          				    Notification.Type.ERROR_MESSAGE, true);
          			notif.show(Page.getCurrent());
        		    
            	}    
            }
					            
        });
        
        save.addShortcutListener(entersave);
        cancel.addShortcutListener(entercancel);
        registerPanel.addComponent(fields);
        RegisterLayout.addComponent(registerPanel);
        RegisterLayout.setComponentAlignment(registerPanel, Alignment.MIDDLE_CENTER);
        
        }
		  
	/*Function to build the main structure of the web Application
	 * 
	 */
	protected void buildMainView( final String Uname) {
		 
		nav = new Navigator(this, content);
		 
        for (String route : routes.keySet()) {
            nav.addView(route, routes.get(route));
        }

        removeStyleName("login");
        root.removeComponent(loginLayout);
        root.addComponent(new HorizontalLayout() {
            {
                setSizeFull();
                addStyleName("main-view");
                addComponent(new VerticalLayout() {
                    // Sidebar
                    {
                        addStyleName("sidebar");
                        setWidth(null);
                        setHeight("100%");

                        // Branding element
                        addComponent(new CssLayout() {
                            {
                                addStyleName("branding");
                                Label logo = new Label(
                                        "<span><i>  Health Predictor 1.0 </i></span>",
                                        ContentMode.HTML);
                                
                                logo.setIcon(new ThemeResource("img/nlogo.jpg"));
                                logo.setSizeUndefined();
                                logo.addStyleName("h4");
                                addComponent(logo);
                                
                            }
                        });

                        // Main menu
                        addComponent(menu);
                        setExpandRatio(menu, 1);

                       // User menu
                        addComponent(new VerticalLayout() {
                            {
                                setSizeUndefined();
                                addStyleName("user");
                                Image profilePic = new Image(
                                        null,
                                        new ThemeResource("img/profile-pic.png"));
                                profilePic.setWidth("34px");
                                addComponent(profilePic);
                                name=getUsername(Uname);
                                Label username = new Label(name);
                                username.setSizeUndefined();
                                addComponent(username);

                                Command MyAccountcmd = new Command() {
                                    @Override
                                    public void menuSelected(
                                            MenuItem selectedItem) {
                                        content.removeAllComponents();
                                        editUserProfile(Uname);
                                       
                                        
                                		
                                    }
                                };
                                Command SignOutcmd = new Command() {
                                    @Override
                                    public void menuSelected(
                                            MenuItem selectedItem) {
                                    	buildLoginView(true);
                                    	
                                    	
                                    }
                                };
                                Command changePwdcmd = new Command() {
                                    @Override
                                    public void menuSelected(
                                            MenuItem selectedItem) {
                                    	
                                    	content.removeAllComponents();
                                    	ChangePassword(Uname);
                                    	
                                    }
                                };
                                MenuBar settings = new MenuBar();
                                MenuItem settingsMenu = settings.addItem("",
                                        null);
                                 settingsMenu.setStyleName("icon-cog");
                                 settingsMenu.addItem("Edit my Profile", MyAccountcmd);
                                 settingsMenu.addItem("Change Password", changePwdcmd);
                                 settingsMenu.addItem("Sign Out",SignOutcmd);
                                addComponent(settings);
                               
                            }
                        });
                    }
                });
                // Content
                addComponent(content);
                content.setSizeFull();
                content.addStyleName("view-content");
                setExpandRatio(content, 1);
                
            }

        });

        menu.removeAllComponents();
        for (final String view : new String[] { "Home Page", "Patient Dashboard","Create Patient Profile",
                "Run Diagnosis" }) {
            Button b = new NativeButton(view.substring(0, 1).toUpperCase()
                    + view.substring(1).replace('-', ' '));
            b.addStyleName("icon-" + view);
            b.addClickListener(new ClickListener() {
                @Override
                public void buttonClick(ClickEvent event) {
                    clearMenuSelection();
                    event.getButton().addStyleName("selected");
                    if (!nav.getState().equals("/" + view))
                    	getUI().getNavigator().navigateTo("/" + view);
                }

				
            });
          
               menu.addComponent(b);
            

            viewNameToMenuButton.put("/" + view, b);
        }
        menu.addStyleName("menu");
        menu.setHeight("100%");
        viewNameToMenuButton.get("/Home Page").setHtmlContentAllowed(true);
        viewNameToMenuButton.get("/Home Page").setCaption(
                "Home Page");
        String f = Page.getCurrent().getUriFragment();
        if (f != null && f.startsWith("!")) {
            f = f.substring(1);
        }
        if (f == null || f.equals("") || f.equals("/")) {
        	nav.navigateTo("/Home Page");
            menu.getComponent(0).addStyleName("selected");
        } else {
            nav.navigateTo(f);
            viewNameToMenuButton.get(f).addStyleName("selected");
        }
        nav.addViewChangeListener(new ViewChangeListener() {

            @Override
            public boolean beforeViewChange(ViewChangeEvent event) {
            	
    			           
                return true;
            }

            @Override
            public void afterViewChange(ViewChangeEvent event) {
                View newView = event.getNewView();
               
                    newView.getClass();          
                
            }
        });
        
	}
	/*
	 * Function definition for clearing the menu selection
	 */
	private void clearMenuSelection() {
        for (Iterator<Component> it = menu.iterator(); it.hasNext();) {
            Component next = it.next();
            if (next instanceof NativeButton) {
                next.removeStyleName("selected");
            } else if (next instanceof DragAndDropWrapper) {
                ((DragAndDropWrapper) next).iterator().next()
                        .removeStyleName("selected");
            }
        }
    }
	/*
	 * Function definition for authenticating user	 
	 */
	public int authenticateUser(String Uname,String pwd){
		 
		  int size = 0;
		  int UID= Integer.parseInt(Uname);
		  SQLContainer dContainer = null;
		  dContainer=dbHelp.getDoctorContainer();
		  dContainer.removeAllContainerFilters();
		  dContainer.removeAllContainerFilters();
		  dContainer.addContainerFilter(new And(new Compare.Equal ("doctor_ID",UID),(new Compare.Equal ("doctor_pwd",pwd))));
		 
		  size =dContainer.size();
		  
		  return size;
    	
		
	}
	/*
	 * Function definition for getting the user name from the database by using the User ID provided from the login
	 * User name is displayed in the main page  
	 */
	public String getUsername(String Uname){
		 
		  String s = null;
		  int UID= Integer.parseInt(Uname);
		  JDBCConnectionPool con=dbHelp.initConnectionPool();
		  FreeformQuery query = new FreeformQuery(" SELECT doctor_name from doctor_table" + 
				  " WHERE " + "doctor_ID="+UID,con,"doctor_name");
		  try {
			SQLContainer container = new SQLContainer(query);
			Object itemId=container.firstItemId();
			s=container.getItem(itemId).getItemProperty("doctor_name").getValue().toString();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 con.destroy();	   
		  return s; 
  	
		
	}
	/*
	 * Function definition for editing the user profile
	 */
	public void  editUserProfile( final String Uname){
		VerticalLayout vlayout= new VerticalLayout();
        Panel panel= new Panel();
        panel.addStyleName("login-panel");
        panel.setSizeUndefined();
        FormLayout layout= new FormLayout();
        Label l= new Label(" Edit User Profile");
        layout.addComponent(l);
        panel.setContent(layout);
        
        int UID= Integer.parseInt(Uname);
        dbHelp.getDoctorContainer().removeAllContainerFilters();
		final SQLContainer container=dbHelp.getDoctorContainer();
		container.addContainerFilter(new Compare.Equal ("doctor_ID",UID));
		
		final Object itemId=container.firstItemId();
		String usrName=container.getItem(itemId).getItemProperty("doctor_name").getValue().toString();
		String usrPh=container.getItem(itemId).getItemProperty("doctor_phNo").getValue().toString();
		String usraddress=container.getItem(itemId).getItemProperty("doctor_address").getValue().toString();
		String usrspeciality=container.getItem(itemId).getItemProperty("speciality").getValue().toString();
		final TextField tname=new TextField("Name:");
		tname.setValue(usrName);
		final TextField tph=new TextField("Phone Number:");
		tph.setValue(usrPh);
		final TextField taddress=new TextField("Address:");
		taddress.setValue(usraddress);
		final TextField tspeciality=new TextField("Speciality:");
		tspeciality.setValue(usrspeciality);
		HorizontalLayout tbuttons= new HorizontalLayout();
		final Button save=new Button("Save");
		save.addStyleName("default");
		tbuttons.addComponent(save);
		final Button cancel=new Button("Cancel");
		cancel.addStyleName("default");
		tbuttons.setSpacing(true);
		tbuttons.addComponent(cancel);
		final ShortcutListener entersave = new ShortcutListener("Save",
                KeyCode.ENTER, null) {
            @Override
            public void handleAction(Object sender, Object target) {
               save.click();
            }
    };
    save.addClickListener(new ClickListener() {
        	
            @SuppressWarnings("unchecked")
			@Override
            public void buttonClick(ClickEvent event) {
            	
            	                	
            	                	
            	                	int d_ph = Integer.parseInt(tph.getValue());
            	                	          	                	
        
            	                	container.getItem(itemId).getItemProperty("doctor_name").setValue(tname.getValue());
            	                	container.getItem(itemId).getItemProperty("doctor_phNo").setValue(d_ph);
            	                	container.getItem(itemId).getItemProperty("doctor_address").setValue(taddress.getValue());
            	                	container.getItem(itemId).getItemProperty("speciality").setValue(tspeciality.getValue());
	            	            		
	            	                	try {
											container.commit();
											Notification.show("Your Profile is Updated");
											getUI().getNavigator().addView("/Home Page",HomePage.class);
			            	          		getUI().getNavigator().navigateTo("/Home Page");
			            	          		
											
											
										} catch (UnsupportedOperationException e) {
											Notification notif=new Notification("Error","<br/>Invalid!!",
	            	          				    Notification.Type.ERROR_MESSAGE, true);
	            	          			notif.show(Page.getCurrent());
											e.printStackTrace();
										} catch (SQLException e) {
											Notification notif=new Notification("Error","<br/>Invalid Data",
	            	          				    Notification.Type.ERROR_MESSAGE, true);
	            	          			notif.show(Page.getCurrent());
											e.printStackTrace();
										}
            	                	
            	                	
            	            }
            	                
            	            
            	        });
            	
  
    	save.addShortcutListener(entersave);
    	final ShortcutListener cancelsave = new ShortcutListener("Cancel",
                KeyCode.ENTER, null) {
            @Override
            public void handleAction(Object sender, Object target) {
               cancel.click();
            }
    };
    cancel.addClickListener(new ClickListener() {
        	
            
			@Override
            public void buttonClick(ClickEvent event) {
            	
				getUI().getNavigator().addView("/Home Page",HomePage.class);
          		getUI().getNavigator().navigateTo("/Home Page");
            	                	
            	                	
            	                	
            	                	
            	            }
            	                
            	            
            	        });
            	
    	
    	cancel.addShortcutListener(cancelsave);
    	layout.addComponent(tname);
    	layout.addComponent(tph);
    	layout.addComponent(taddress);
    	layout.addComponent(tspeciality);
    	layout.addComponent(tbuttons);
    	layout.setComponentAlignment(tbuttons, Alignment.BOTTOM_LEFT);
		panel.setContent(layout);
		vlayout.addComponent(panel);
        vlayout.setComponentAlignment(panel, Alignment.MIDDLE_CENTER);
        content.addComponent(vlayout);
	}
	/*
	 * Function definition to change the user password
	 */
public void ChangePassword(final String Uname){
	VerticalLayout vlayout= new VerticalLayout();
    Panel panel= new Panel();
    panel.addStyleName("login-panel");
    panel.setSizeUndefined();
    FormLayout layout= new FormLayout();
    Label l= new Label(" Change Password");
    layout.addComponent(l);
    panel.setContent(layout);
    
    int UID= Integer.parseInt(Uname);
    dbHelp.getDoctorContainer().removeAllContainerFilters();
	final SQLContainer container=dbHelp.getDoctorContainer();
	container.addContainerFilter(new Compare.Equal ("doctor_ID",UID));
	
	final Object itemId=container.firstItemId();
	final String usrpwd=container.getItem(itemId).getItemProperty("doctor_pwd").getValue().toString();
	
	final  PasswordField oldPassword =new PasswordField("Old Password:");
	final  PasswordField newPassword =new PasswordField("New Password:");
	
	HorizontalLayout tbuttons= new HorizontalLayout();
	final Button save=new Button("Save");
	save.addStyleName("default");
	tbuttons.addComponent(save);
	final Button cancel=new Button("Cancel");
	cancel.addStyleName("default");
	tbuttons.setSpacing(true);
	tbuttons.addComponent(cancel);
	final ShortcutListener entersave = new ShortcutListener("Save",
            KeyCode.ENTER, null) {
        @Override
        public void handleAction(Object sender, Object target) {
           save.click();
        	}
		};
		save.addClickListener(new ClickListener() {
    	
        @SuppressWarnings("unchecked")
		@Override
        public void buttonClick(ClickEvent event) {
        						
        	                	if (oldPassword.getValue().equals(usrpwd)){
        	                		container.getItem(itemId).getItemProperty("doctor_pwd").setValue(newPassword.getValue());
        	                	           	            		
            	                	try {
										container.commit();
										Notification.show("Password has been changed");
										getUI().getNavigator().addView("/Home Page",HomePage.class);
		            	          		getUI().getNavigator().navigateTo("/Home Page");
										
									} 
									catch (Exception e) {
										Notification notif=new Notification("Error","<br/>Invalid Data",
            	          				    Notification.Type.ERROR_MESSAGE, true);
            	          			notif.show(Page.getCurrent());
										e.printStackTrace();
									}
        	                	}
        	                	else{
        	                		Notification notif=new Notification("Error","<br/>Old Password doesn't match",
            	          				    Notification.Type.ERROR_MESSAGE, true);
            	          			notif.show(Page.getCurrent());
        	                	}
        	                	          	                	
    
        	                	
        	                	
        	                	
        	            }
        	                
        	            
        	        });
        	

	save.addShortcutListener(entersave);
	final ShortcutListener cancelsave = new ShortcutListener("Cancel",
            KeyCode.ENTER, null) {
        @Override
        public void handleAction(Object sender, Object target) {
           cancel.click();
        }
};
cancel.addClickListener(new ClickListener() {
    	
        
		@Override
        public void buttonClick(ClickEvent event) {
        	
			getUI().getNavigator().addView("/Home Page",HomePage.class);
      		getUI().getNavigator().navigateTo("/Home Page");
        	                	
        	                	
        	                	
        	                	
        	            }
        	                
        	            
        	        });
        	
	
	cancel.addShortcutListener(cancelsave);
	layout.addComponent(oldPassword);
	layout.addComponent(newPassword);
	
	layout.addComponent(tbuttons);
	layout.setComponentAlignment(tbuttons, Alignment.BOTTOM_LEFT);
	panel.setContent(layout);
	vlayout.addComponent(panel);
    vlayout.setComponentAlignment(panel, Alignment.MIDDLE_CENTER);
    content.addComponent(vlayout);
	}
	        
}  

            
        
		
	