package diseasePredictor;
import java.sql.SQLException;

import com.google.gwt.user.client.ui.RichTextArea;
import com.vaadin.data.Property;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.util.filter.Compare;
import com.vaadin.data.util.sqlcontainer.SQLContainer;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.event.ShortcutListener;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.BrowserWindowOpener;
import com.vaadin.server.Page;
import com.vaadin.server.Sizeable;
import com.vaadin.server.StreamResource.StreamSource;
import com.vaadin.server.ThemeResource;
import com.vaadin.shared.ui.MarginInfo;
import com.vaadin.shared.ui.label.ContentMode;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.CheckBox;
import com.vaadin.ui.Component;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.Flash;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.HorizontalSplitPanel;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Panel;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.TabSheet;
import com.vaadin.ui.TabSheet.CloseHandler;
import com.vaadin.ui.TextArea;
import com.vaadin.ui.TextField;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.Window;

public class RunDiagnosis extends VerticalLayout implements View{
	/**
	 * View to run diagnosis on the patient previous and new medical condition
	 * After data analysis a report is generated for individual patient
	 */
	private static final long serialVersionUID = 2514422583443203364L;
	final DatabaseHelper dbHelp = new DatabaseHelper();
	public String username;
	public int fluIndex=0;
	private TabSheet editors;
	public RunDiagnosis() {
        setSizeFull();
        }        
        
    @Override
    public void enter(ViewChangeEvent event) {
    	
    	this.username = String.valueOf(getSession().getAttribute("user"));
    	setSizeFull();
    	addStyleName("login-panel");
       addComponent(runDiagnosis());
    }

	private Component runDiagnosis() {
		editors = new TabSheet();
        editors.setSizeFull();
        //editors.addStyleName("borderless");
        editors.addStyleName("editors");
        final VerticalLayout firsttab=new VerticalLayout();
        Flash flash = new Flash(null,
			    new ThemeResource("img/diagnosis-rx.jpg"));
        firsttab.addComponent(flash);
        final TextField p_ID= new TextField("Enter Patient ID:");
        p_ID.setRequired(true);
        final VerticalLayout secondtab=new VerticalLayout();
        Flash flash2 = new Flash(null,
        		new ThemeResource("img/Medical.jpg"));
        secondtab.addComponent(flash2);
        final TextField p_ID2= new TextField("Enter Patient ID:");
        p_ID2.setRequired(true);
        Panel panel= new Panel("General Illness Symptoms");
		FormLayout flu = new FormLayout();
		final CheckBox q1= new CheckBox("100 degree F or higher fever or feeling feverish");
		final CheckBox q2= new CheckBox("Cough and/or sore throat");
		final CheckBox q3= new CheckBox("Headaches and/or body aches");
		final CheckBox q4= new CheckBox("Runny or stuffy nose");
		final CheckBox q5= new CheckBox("Chills and Fatigue");
		final CheckBox q6= new CheckBox("Loss Of Appetite");
		final TextField BloodPressure=new TextField("Blood Pressure(mmHg-systolic):");
		final TextField BloodSugarLevel=new TextField("Blood Sugar level(mmol/L):");
		final TextField tBodyTemperature=new TextField("Body temperature( degree F):");
		final TextField tColesterolLevel=new TextField("Colesterol level(%):");
		flu.addComponent(q1);
		flu.addComponent(q2);
		flu.addComponent(q3);
		flu.addComponent(q4);
		flu.addComponent(q5);
		flu.addComponent(q6);
		flu.addComponent(BloodPressure);
		flu.addComponent(BloodSugarLevel);
		flu.addComponent(tBodyTemperature);
		flu.addComponent(tColesterolLevel);
		panel.setContent(flu);
		firsttab.addComponent(p_ID);
        final Button run= new Button("RUN Diagnosis");
        firsttab.addComponent(run);
		final Button run2= new Button("RUN Diagnosis");
		secondtab.addComponent(p_ID2);
		secondtab.addComponent(panel);
		secondtab.addComponent(run2);
		
		 final ShortcutListener enter = new ShortcutListener("RUN Diagnosis",
	                KeyCode.ENTER, null) {
	            /**
						 * 
						 */
						private static final long serialVersionUID = 1L;

				@Override
	            public void handleAction(Object sender, Object target) {
	            	 run.click();
	            }
	        };
	        run.addClickListener(new ClickListener() {
	        		            
				/**
				 * 
				 */
				private static final long serialVersionUID = 1L;

				@Override
	            public void buttonClick(ClickEvent event) {
					int UID = 0;
					try{
					UID= Integer.parseInt(p_ID.getValue());
					
					dbHelp.getPatientContainer().removeAllContainerFilters();
					dbHelp.getPatientContainer().addContainerFilter(new Compare.Equal ("patient_ID",UID));
					
					SQLContainer container=dbHelp.getPatientContainer();
					int size= container.size();
					if (size== 0){
						
						
						Notification notif=new Notification("Error","<br/>Patient ID does not exist!",
	          				    Notification.Type.ERROR_MESSAGE, true);
						notif.setStyleName("Notification");
	          			notif.show(Page.getCurrent());
	          			
					}
					else
					{
							container.addContainerFilter(new Compare.Equal ("status","Dead"));
							container=dbHelp.getPatientContainer();
							if (container.size()==1){
								Notification notif=new Notification("Error","<br/>Patient is Dead!",
			          				    Notification.Type.ERROR_MESSAGE, true);
								notif.setStyleName("Notification");
			          			notif.show(Page.getCurrent());
							}
							else{
								container.removeAllContainerFilters();
								container.addContainerFilter(new Compare.Equal ("patient_ID",UID));
								
							VerticalLayout report= new VerticalLayout();
													
							report.setHeight("100%");
							
							
							Label l= new Label("Health Prediction Report");
							l.setIcon(new ThemeResource("img/icons6429.png"));
					       
							l.addStyleName("h2");
							
							final Object itemId=container.firstItemId();
							String name=container.getItem(itemId).getItemProperty("patient_Name").getValue().toString();
							String sex=container.getItem(itemId).getItemProperty("Sex").getValue().toString();
							if (sex.equals("M")){
								sex="Male";
							}
							else{
								sex="Female";
							}
							String bp=null;
							String healthStatus=null;
							String age=container.getItem(itemId).getItemProperty("patient_Age").getValue().toString();
							String address=container.getItem(itemId).getItemProperty("patient_Address").getValue().toString();
							String ph=container.getItem(itemId).getItemProperty("patient_PhNo").getValue().toString();
							String nBloodPressure=container.getItem(itemId).getItemProperty("BloodPressure").getValue().toString();
							String nBloodSugarLevel=container.getItem(itemId).getItemProperty("BloodSugarLevel").getValue().toString();
							String nBodyTemperature=container.getItem(itemId).getItemProperty("BodyTemperature").getValue().toString();
							String nColesterolLevel=container.getItem(itemId).getItemProperty("ColesterolLevel").getValue().toString();
							//String healthIndex=container.getItem(itemId).getItemProperty("HealthIndex").getValue().toString();
							int p_bloodPressure = Integer.parseInt(nBloodPressure);
					    	if(p_bloodPressure>120){
					    		bp=".The patient has High blood pressure.";
					    		healthStatus=" The Patient is Not Healthy and needs medical care";
					    	}
					    	else{
					    		bp=".The patient has normal blood pressure";
					    		healthStatus=" The patient is Healthy";
					    	}
					    	String bs=null;
							int p_bloodsugar = Integer.parseInt(nBloodSugarLevel);
					    	if(p_bloodsugar> 126){
					    		bs=".The Patient has Diebetes";
					    		healthStatus=" The Patient is Not Healthy and needs medical care";
					    		
					    	}
					    	else{
					    		bs=".The Patient has normal blood sugar level";
					    		healthStatus=" The patient is Healthy";
					    	}
					    	String tem= null;
					    	int p_temp = Integer.parseInt(nBodyTemperature);
					    	if(p_temp> 100){
					    		tem=".The Patient has high  body temperature";
					    		healthStatus=" The Patient is Not Healthy and needs medical care";
					    	}
					    	else{
					    		tem=".The Patient has normal body temperature";
					    		healthStatus=" The patient is Healthy";
					    	}
					    	String col=null;
					    	int p_col = Integer.parseInt(nColesterolLevel);
					    	if(p_col> 20){
					    		col=".The Patient has high cholesterol level";
					    		healthStatus=" The Patient is Not Healthy and needs medical care";
					    	}
					    	else{
					    		col=".The Patient has normal colesterol level";
					    		healthStatus=" The patient is Healthy";
					    	}
					    	
							com.vaadin.ui.Label lname=new com.vaadin.ui.Label("Name: "+ name);
							com.vaadin.ui.Label lsex=new com.vaadin.ui.Label("Sex: "+ sex);
							com.vaadin.ui.Label lage=new com.vaadin.ui.Label("Age: "+ age);
							com.vaadin.ui.Label laddress=new com.vaadin.ui.Label("Address: "+ address);
							com.vaadin.ui.Label lph=new com.vaadin.ui.Label("Phone Number: "+ ph);
							com.vaadin.ui.Label lBloodPressure=new com.vaadin.ui.Label("Blood Pressure(mmHg-systolic): "+  nBloodPressure);
							com.vaadin.ui.Label lBloodSugarLevel=new com.vaadin.ui.Label("Blood Sugar level(mmol/L): "+ nBloodSugarLevel);
							com.vaadin.ui.Label lBodyTemperature=new com.vaadin.ui.Label("Body temperature( degree F): "+ nBodyTemperature);
							com.vaadin.ui.Label lColesterolLevel=new com.vaadin.ui.Label("Colesterol level(%): "+ nColesterolLevel);
							
							Panel panel = new Panel("Doctor's Comments:");
					        panel.addStyleName("login-panel");
					        panel.setSizeUndefined();
					        VerticalLayout comments = new VerticalLayout();
					        
							Label lbp=new Label(bp);
							Label lbs=new Label(bs);
							Label ltem=new Label(tem);
							Label lcol=new Label(col);
							comments.addComponent(lbp);
							comments.addComponent(lbs);
							comments.addComponent(ltem);
							comments.addComponent(lcol);
							comments.setSizeUndefined();
							panel.setContent(comments);
																			
							 
					        
					        
					  		report.addComponent(l);
							report.addComponent(lname);
							report.addComponent(lage);
							report.addComponent(lsex);
							report.addComponent(laddress);
							report.addComponent(lph);
							
							
							report.addComponent(lBloodPressure);
							report.setSpacing(true);
							report.addComponent(lBloodSugarLevel);
							report.setSpacing(true);
							report.addComponent(lBodyTemperature);
							report.setSpacing(true);
							report.addComponent(lColesterolLevel);
							
							report.addComponent(panel);
							//report.setSpacing(false);
							firsttab.removeAllComponents();
							firsttab.setSizeUndefined();
							firsttab.addComponent(report);
						}							
					}
					}
					catch(Exception e){
						Notification notif=new Notification("Error","<br/>Invalid ID!",
	          				    Notification.Type.ERROR_MESSAGE, true);
						notif.setStyleName("Notification");
	          			notif.show(Page.getCurrent());
					}
					
					
	            }
	            
	        });
	        
	        run.addShortcutListener(enter);
	        final ShortcutListener enter2 = new ShortcutListener("RUN Diagnosis",
	                KeyCode.ENTER, null) {
	            /**
						 * 
						 */
						private static final long serialVersionUID = 1L;

				@Override
	            public void handleAction(Object sender, Object target) {
	            	 run2.click();
	            }
	        };
	        run2.addClickListener(new ClickListener() {

				/**
				 * 
				 */
				private static final long serialVersionUID = 1L;

				@SuppressWarnings("unchecked")
				@Override
				public void buttonClick(ClickEvent event) {
					int UID = 0;
					try{
					UID= Integer.parseInt(p_ID2.getValue());
					
					dbHelp.getPatientContainer().removeAllContainerFilters();
					dbHelp.getPatientContainer().addContainerFilter(new Compare.Equal ("patient_ID",UID));
					
					SQLContainer container=dbHelp.getPatientContainer();
					int size= container.size();
					if (size== 0){
						
						
						Notification notif=new Notification("Error","<br/>Patient ID does not exist!",
	          				    Notification.Type.ERROR_MESSAGE, true);
						notif.setStyleName("Notification");
	          			notif.show(Page.getCurrent());
	          			
					}else
					{
						container.addContainerFilter(new Compare.Equal ("status","Dead"));
						container=dbHelp.getPatientContainer();
						if (container.size()==1){
							Notification notif=new Notification("Error","<br/>Patient is Dead!",
		          				    Notification.Type.ERROR_MESSAGE, true);
							notif.setStyleName("Notification");
		          			notif.show(Page.getCurrent());
						}
						else{
							container.removeAllContainerFilters();
							container.addContainerFilter(new Compare.Equal ("patient_ID",UID));
							VerticalLayout report= new VerticalLayout();
							
							report.setHeight("100%");
							
							
							Label l= new Label("Health Prediction Report");
							l.setIcon(new ThemeResource("img/icons6429.png"));
					       
							l.addStyleName("h2");
							final Object itemId=container.firstItemId();
							String name=container.getItem(itemId).getItemProperty("patient_Name").getValue().toString();
							String sex=container.getItem(itemId).getItemProperty("Sex").getValue().toString();
							if (sex.equals("M")){
								sex="Male";
							}
							else{
								sex="Female";
							}
							String bp=null;
							String healthStatus=null;
							String age=container.getItem(itemId).getItemProperty("patient_Age").getValue().toString();
							String address=container.getItem(itemId).getItemProperty("patient_Address").getValue().toString();
							String ph=container.getItem(itemId).getItemProperty("patient_PhNo").getValue().toString();
							try{
							int p_bloodPressure = Integer.parseInt(BloodPressure.getValue());
					    	if(p_bloodPressure>120){
					    		bp=".The patient has High blood pressure.";
					    		healthStatus=" The Patient is Not Healthy and needs medical care";
					    	}
					    	else{
					    		bp=".The patient has normal blood pressure";
					    		healthStatus=" The patient is Healthy";
					    	}
					    	String bs=null;
							int p_bloodsugar = Integer.parseInt(BloodSugarLevel.getValue());
					    	if(p_bloodsugar> 126){
					    		bs=".The Patient has Diebetes";
					    		healthStatus=" The Patient is Not Healthy and needs medical care";
					    		
					    	}
					    	else{
					    		bs=".The Patient has normal blood sugar level";
					    		healthStatus=" The patient is Healthy";
					    	}
					    	String tem= null;
					    	int p_temp = Integer.parseInt(tBodyTemperature.getValue());
					    	if(p_temp> 100){
					    		tem=".The Patient has high  body temperature";
					    		healthStatus=" The Patient is Not Healthy and needs medical care";
					    	}
					    	else{
					    		tem=".The Patient has normal body temperature";
					    		healthStatus=" The patient is Healthy";
					    	}
					    	String col=null;
					    	int p_col = Integer.parseInt(tColesterolLevel.getValue());
					    	if(p_col> 20){
					    		col=".The Patient has high cholesterol level";
					    		healthStatus=" The Patient is Not Healthy and needs medical care";
					    	}
					    	else{
					    		col=".The Patient has normal colesterol level";
					    		healthStatus=" The patient is Healthy";
					    	}
							
					    	
					    	q2.addValueChangeListener(new Property.ValueChangeListener() {
					            private static final long serialVersionUID = -6857112166321059475L;

					            public void valueChange(ValueChangeEvent event) {
					                @SuppressWarnings("unused")
									boolean value = (Boolean) event.getProperty().getValue();
					                if(value=true){
					                	fluIndex+=1;
					                }
					                else{
					                //do nothing	
					                }
					            }
					        });
					    	q3.addValueChangeListener(new Property.ValueChangeListener() {
					            private static final long serialVersionUID = -6857112166321059475L;

					            public void valueChange(ValueChangeEvent event) {
					                @SuppressWarnings("unused")
									boolean value = (Boolean) event.getProperty().getValue();
					                if(value=true){
					                	fluIndex+=1;
					                }
					                else{
					                //do nothing	
					                }
					            }
					        });
					    	q4.addValueChangeListener(new Property.ValueChangeListener() {
					            private static final long serialVersionUID = -6857112166321059475L;

					            public void valueChange(ValueChangeEvent event) {
					                @SuppressWarnings("unused")
									boolean value = (Boolean) event.getProperty().getValue();
					                if(value=true){
					                	fluIndex+=1;
					                }
					                else{
					                //do nothing	
					                }
					            }
					        });
					    	q5.addValueChangeListener(new Property.ValueChangeListener() {
					            private static final long serialVersionUID = -6857112166321059475L;

					            public void valueChange(ValueChangeEvent event) {
					                @SuppressWarnings("unused")
									boolean value = (Boolean) event.getProperty().getValue();
					                if(value=true){
					                	fluIndex+=1;
					                }
					                else{
					                //do nothing	
					                }
					            }
					        });
					    	q6.addValueChangeListener(new Property.ValueChangeListener() {
					            private static final long serialVersionUID = -6857112166321059475L;

					            public void valueChange(ValueChangeEvent event) {
					                @SuppressWarnings("unused")
									boolean value = (Boolean) event.getProperty().getValue();
					                if(value=true){
					                	fluIndex+=1;
					                }
					                else{
					                //do nothing	
					                }
					            }
					        });
					    	String flureport=null;
					    	if(fluIndex>=4){
					    		flureport=" The patient is suffering from severe flu and need medication ";
					    	}else {
					    		flureport=" The patient is mild symptoms of flu and rest is recommended  ";
					    	}
					    	container.getItem(itemId).getItemProperty("BloodPressure").setValue(p_bloodPressure);
      	            		container.getItem(itemId).getItemProperty("BloodSugarLevel").setValue(p_bloodsugar);
      	            		container.getItem(itemId).getItemProperty("BodyTemperature").setValue(p_temp);
      	            		container.getItem(itemId).getItemProperty("ColesterolLevel").setValue(p_col);
      	            		try{
      	            			container.commit();
      	            		}catch(SQLException e){
      	            			e.printStackTrace();
      	            		}
							
							com.vaadin.ui.Label lname=new com.vaadin.ui.Label("Name: "+ name);
							com.vaadin.ui.Label lsex=new com.vaadin.ui.Label("Sex: "+ sex);
							com.vaadin.ui.Label lage=new com.vaadin.ui.Label("Age: "+ age);
							com.vaadin.ui.Label laddress=new com.vaadin.ui.Label("Address: "+ address);
							com.vaadin.ui.Label lph=new com.vaadin.ui.Label("Phone Number: "+ ph);
							com.vaadin.ui.Label lBloodPressure=new com.vaadin.ui.Label("Blood Pressure(mmHg-systolic): "+ BloodPressure.getValue());
							com.vaadin.ui.Label lBloodSugarLevel=new com.vaadin.ui.Label("Blood Sugar level(mmol/L): "+ BloodSugarLevel.getValue());
							com.vaadin.ui.Label lBodyTemperature=new com.vaadin.ui.Label("Body temperature( degree F): "+ tBodyTemperature.getValue());
							com.vaadin.ui.Label lColesterolLevel=new com.vaadin.ui.Label("Colesterol level(%): "+ tBodyTemperature.getValue());
							
							Panel panel = new Panel("Doctor's Comments: ");
					        panel.addStyleName("login-panel");
					        panel.setSizeUndefined();
					        VerticalLayout comments = new VerticalLayout();
					        
							Label lbp=new Label(bp);
							Label lbs=new Label(bs);
							Label ltem=new Label(tem);
							Label lcol=new Label(col);
							Label lflu=new Label(flureport);
							comments.addComponent(lbp);
							comments.addComponent(lbs);
							comments.addComponent(ltem);
							comments.addComponent(lcol);
							comments.addComponent(lflu);
					    	
							comments.setSizeUndefined();
							panel.setContent(comments);
																			
							 
					        
					        
					  		report.addComponent(l);
							report.addComponent(lname);
							report.addComponent(lage);
							report.addComponent(lsex);
							report.addComponent(laddress);
							report.addComponent(lph);
							
							
							report.addComponent(lBloodPressure);
							report.setSpacing(true);
							report.addComponent(lBloodSugarLevel);
							report.setSpacing(true);
							report.addComponent(lBodyTemperature);
							report.setSpacing(true);
							report.addComponent(lColesterolLevel);
							
							report.addComponent(panel);
							secondtab.removeAllComponents();
							secondtab.setSizeUndefined();
							secondtab.addComponent(report);
							}catch(Exception e){
								Notification notif=new Notification("Error","<br/>Invalid Data!",
			          				    Notification.Type.ERROR_MESSAGE, true);
								notif.setStyleName("Notification");
			          			notif.show(Page.getCurrent());
							}	
							//report.setSpacing(false);
						}
					
					}
					}catch(Exception e){
						Notification notif=new Notification("Error","<br/>Invalid ID!",
	          				    Notification.Type.ERROR_MESSAGE, true);
						notif.setStyleName("Notification");
	          			notif.show(Page.getCurrent());
					
				}
				}
	        
	        });
	        run2.addShortcutListener(enter2);
        editors.addTab(firsttab,
                "On Previous Medical History",
                null);
        editors.addTab(secondtab,
                "On New Medical Conditions",
                null);
        
        return editors;
    }
	

 

		
	
}