package diseasePredictor;

import org.vaadin.dialogs.ConfirmDialog;
import com.vaadin.data.Property;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.util.sqlcontainer.SQLContainer;
import com.vaadin.event.ShortcutListener;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.Page;
import com.vaadin.server.ThemeResource;
import com.vaadin.ui.Button;
import com.vaadin.ui.CheckBox;
import com.vaadin.ui.Flash;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.GridLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Notification;
import com.vaadin.ui.OptionGroup;
import com.vaadin.ui.Panel;
import com.vaadin.ui.TextField;
import com.vaadin.ui.UI;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.VerticalSplitPanel;
public class CreatePatient  extends VerticalSplitPanel implements View{
	
	/**
	 * CreatePatient class is used to create a view for creating a new patient profile
	 */
	private static final long serialVersionUID = 3404623506208772061L;
	final DatabaseHelper dbHelp = new DatabaseHelper();
	public String username;
	public int healthIndex;
	public int docID;
	public String sex=null;
	public CreatePatient() {
        setSizeFull();
        
        }        
        
    
	@Override
    public void enter(ViewChangeEvent event) {
		//addStyleName("view");
        //Notification.show("Create Patient");
		this.username = String.valueOf(getSession().getAttribute("user"));
		addStyleName("login-panel");
		CreatePatientForm();
				 
		
		
		
    }


	private void CreatePatientForm() {
		HorizontalLayout layout1= new HorizontalLayout();
		Panel panel= new Panel("Create Patient Profile");	
		panel.setSizeUndefined(); 
		panel.setStyleName("panel");
		GridLayout content = new GridLayout(2,5);
		content.setSpacing(true);
		content.setWidth("800px");
		content.setHeight("200px");
		
		final TextField p_name= new TextField("Name:");
		p_name.setIcon(new ThemeResource("img/profile-pic.png"));
		final OptionGroup p_sex= new OptionGroup("Sex:");
		p_sex.setMultiSelect(false);
		p_sex.addItem("Male");
		p_sex.addItem("Female");
		
		p_sex.addValueChangeListener(new Property.ValueChangeListener() {
            private static final long serialVersionUID = -6857112166321059475L;

            public void valueChange(ValueChangeEvent event) {
                String value = (String) event.getProperty().getValue();
                if(value=="Male"){
                	sex="M";
                }
                else{
                	sex="F";	
                }
            }
        });
		p_sex.setImmediate(true);
		final TextField p_age= new TextField("Age:");
		final TextField p_Address= new TextField("Address:");
		final TextField p_ph= new TextField("Phone Number(only Numbers):");
		final TextField BloodPressure=new TextField("Blood Pressure(mmHg-systolic):");
		final TextField BloodSugarLevel=new TextField("Blood Sugar level(mmol/L):");
		final TextField tBodyTemperature=new TextField("Body temperature( degree F):");
		final TextField tColesterolLevel=new TextField("Colesterol level(%):");
		Panel panel2= new Panel("General IllnessSymptoms");
			FormLayout flu = new FormLayout();
			CheckBox q1= new CheckBox("100 degree F or higher fever or feeling feverish");
			q1.addValueChangeListener(new Property.ValueChangeListener() {
	            private static final long serialVersionUID = -6857112166321059475L;

	            public void valueChange(ValueChangeEvent event) {
	                @SuppressWarnings("unused")
					boolean value = (Boolean) event.getProperty().getValue();
	                if(value=true){
	                healthIndex+=1;
	                }
	                else{
	                //do nothing	
	                }
	            }
	        });
	        q1.setImmediate(true);
			
			CheckBox q2= new CheckBox("Cough and/or sore throat");
			q2.addValueChangeListener(new Property.ValueChangeListener() {
	            private static final long serialVersionUID = -6857112166321059475L;

	            public void valueChange(ValueChangeEvent event) {
	                @SuppressWarnings("unused")
					boolean value = (Boolean) event.getProperty().getValue();
	                if(value=true){
	                healthIndex+=1;
	                }
	                else{
	                //do nothing	
	                }
	            }
	        });
	        q2.setImmediate(true);
			CheckBox q3= new CheckBox("Headaches and/or body aches");
			q3.addValueChangeListener(new Property.ValueChangeListener() {
	            private static final long serialVersionUID = -6857112166321059475L;

	            public void valueChange(ValueChangeEvent event) {
	               
					@SuppressWarnings("unused")
					boolean value = (Boolean) event.getProperty().getValue();
	                if(value=true){
	                healthIndex+=1;
	                }
	                else{
	                //do nothing	
	                }
	            }
	        });
	        q3.setImmediate(true);
			CheckBox q4= new CheckBox("Runny or stuffy nose");
			q4.addValueChangeListener(new Property.ValueChangeListener() {
	            private static final long serialVersionUID = -6857112166321059475L;

	            public void valueChange(ValueChangeEvent event) {
	                @SuppressWarnings("unused")
					boolean value = (Boolean) event.getProperty().getValue();
	                if(value=true){
	                healthIndex+=1;
	                }
	                else{
	                //do nothing	
	                }
	            }
	        });
	        q4.setImmediate(true);
			CheckBox q5= new CheckBox("Chills and Fatigue");
			q5.addValueChangeListener(new Property.ValueChangeListener() {
	            private static final long serialVersionUID = -6857112166321059475L;

	            public void valueChange(ValueChangeEvent event) {
	                @SuppressWarnings("unused")
					boolean value = (Boolean) event.getProperty().getValue();
	                if(value=true){
	                healthIndex+=1;
	                }
	                else{
	                //do nothing	
	                }
	            }
	        });
	        q4.setImmediate(true);
			CheckBox q6= new CheckBox("Loss Of Appetite");
			q6.addValueChangeListener(new Property.ValueChangeListener() {
	            private static final long serialVersionUID = -6857112166321059475L;

	            public void valueChange(ValueChangeEvent event) {
	                @SuppressWarnings("unused")
					boolean value = (Boolean) event.getProperty().getValue();
	                if(value=true){
	                healthIndex+=1;
	                }
	                else{
	                //do nothing	
	                }
	            }
	        });
	        q6.setImmediate(true);
	      
			flu.addComponent(q1);
			flu.addComponent(q2);
			flu.addComponent(q3);
			flu.addComponent(q4);
			flu.addComponent(q5);
			flu.addComponent(q6);
			panel2.setContent(flu);
			
		final Button save=new Button("Save");
		final ShortcutListener entersave = new ShortcutListener("Save",
	                KeyCode.ENTER, null) {
	            /**
						 * 
						 */
						private static final long serialVersionUID = 1L;

				@Override
	            public void handleAction(Object sender, Object target) {
	               save.click();
	            }
	    };
	    save.addClickListener(new ClickListener() {
	        	
	            /**
			 * 
			 */
			private static final long serialVersionUID = 1L;
			
				@Override
	            public void buttonClick(ClickEvent event) {
	            	ConfirmDialog.show(UI.getCurrent(), "Please Confirm:", "",
	            	        " Save", "Cancel", new ConfirmDialog.Listener() {

	            	            /**
								 * 
								 */
								private static final long serialVersionUID = 1L;

								
								@SuppressWarnings("unchecked")
								public void onClose(ConfirmDialog dialog) {
	            	                if (dialog.isConfirmed()) {
	            	                    // Confirmed to continue
	            	                	

	            	                	SQLContainer container= dbHelp.getPatientContainer();	            	          		  
		            	          		  try {
		            	          			Object id = container.addItem();
		            	          			docID = Integer.parseInt(username);
		            	          			int age = Integer.parseInt(p_age.getValue());
		            	                	int ph = Integer.parseInt(p_ph.getValue());
		            	                	int p_bloodPressure = Integer.parseInt(BloodPressure.getValue());
		            	                	if(p_bloodPressure<120){
		            	                		healthIndex+=1;
		            	                	}
		            	                	else{
		            	                		
		            	                	}
		            	                	int p_bloodsugar = Integer.parseInt(BloodSugarLevel.getValue());
		            	                	if(p_bloodsugar> 126){
		            	                		healthIndex+=1;
		            	                	}
		            	                	else{
		            	                		
		            	                	}
		            	                	int p_temp = Integer.parseInt(tBodyTemperature.getValue());
		            	                	if(p_temp> 100){
		            	                		healthIndex+=1;
		            	                	}
		            	                	else{
		            	                		
		            	                	}
		            	                	int p_col = Integer.parseInt(tColesterolLevel.getValue());
		            	                	if(p_col> 20){
		            	                		healthIndex+=1;
		            	                	}
		            	                	else{
		            	                		
		            	                	}
		            	                	
		            	                	
		            	                	container.getContainerProperty(id,"patient_Name").setValue(p_name.getValue());
	  	            	            		container.getContainerProperty(id,"Sex").setValue(sex);
	  	            	            		container.getContainerProperty(id,"patient_Age").setValue(age);
	  	            	            		container.getContainerProperty(id,"patient_Address").setValue(p_Address.getValue());
	  	            	            		container.getContainerProperty(id,"doctor_ID").setValue(docID);
	  	            	            		container.getContainerProperty(id,"patient_PhNo").setValue(ph);
	  	            	            		container.getContainerProperty(id,"BloodPressure").setValue(p_bloodPressure);
	  	            	            		container.getContainerProperty(id,"BloodSugarLevel").setValue(p_bloodsugar);
	  	            	            		container.getContainerProperty(id,"BodyTemperature").setValue(p_temp);
	  	            	            		container.getContainerProperty(id,"ColesterolLevel").setValue(p_col);
	  	            	            		container.getContainerProperty(id,"HealthIndex").setValue(healthIndex);
	  	            	            		container.getContainerProperty(id,"status").setValue("Alive");
		            	          			container.commit();
		            	          			           	          			
		            	          			Notification.show("The Patient Profile is created");
		            	          			getUI().getNavigator().addView("/Patient Dashboard",PatientView.class);
		            	          			getUI().getNavigator().navigateTo("/Patient Dashboard");
		            	          		} catch (Exception e) {
		            	          			Notification notif=new Notification("Error","<br/>Cannot have empty fields!!",
		            	          				    Notification.Type.ERROR_MESSAGE, true);
		            	          			notif.show(Page.getCurrent());	   
		            	          			getUI().getNavigator().addView("/Create Patient Profile",CreatePatient.class);
		            	          			getUI().getNavigator().navigateTo("/Create Patient Profile"); 
		            	          			
		            	          			e.printStackTrace();
		            	          		}
	            	               }
	            	                else{
	            	                	getUI().getNavigator().addView("/Create Patient Profile",CreatePatient.class);
		            	          			getUI().getNavigator().navigateTo("/Create Patient Profile");            	          		   
	            	                	
	            	                }
	            	            }
	            	        });
	            	
	            }
	    });
	    save.addShortcutListener(entersave);
	    content.addComponent(p_name);
		content.addComponent(p_sex);
		content.addComponent(p_age);
		content.addComponent(p_Address);
		content.addComponent(p_ph);
		content.addComponent(BloodPressure);
		content.addComponent(BloodSugarLevel);
		content.addComponent(tBodyTemperature);
		content.addComponent(tColesterolLevel);
		
	    content.setSizeUndefined(); // Shrink to fit
		content.setMargin(true);
		addStyleName("login-panel");
		panel.setContent(content);
		Flash flash = new Flash(null,
			    new ThemeResource("img/kid-symptoms.jpg"));
		layout1.addComponent(flash);
		
		layout1.addComponent(panel);
		
		setFirstComponent(layout1);
		VerticalLayout layout= new VerticalLayout();
		layout.addComponent(panel2);
		layout.addComponent(save);
		setSecondComponent(layout);
	
		
	}
}