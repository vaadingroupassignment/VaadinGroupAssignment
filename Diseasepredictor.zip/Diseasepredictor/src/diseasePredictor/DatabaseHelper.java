package diseasePredictor;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import com.vaadin.data.util.sqlcontainer.SQLContainer;
import com.vaadin.data.util.sqlcontainer.connection.JDBCConnectionPool;
import com.vaadin.data.util.sqlcontainer.connection.SimpleJDBCConnectionPool;
import com.vaadin.data.util.sqlcontainer.query.TableQuery;
/*
 * DatabaseHelper class is used to manage the database connection and create SQLContainer and all other views access the database using this class
 */
public class DatabaseHelper {
	public static final Object[] NATURAL_COL_ORDER = new Object[] {
        "patient_ID", "patient_Name", "Sex", "patient_Age", "patient_PhNo",
        "patient_Address"};

/**
 * "Human readable" captions for properties in same order as in
 * NATURAL_COL_ORDER.
 */
public static final String[] COL_HEADERS_ENGLISH = new String[] {
	"Patient_ID", "Patient_Name", "Sex", "Patient_Age", "Patient_PhNo",
    "Patient_Address" };

private JDBCConnectionPool connectionPool = null;
private SQLContainer doctorContainer = null;
private SQLContainer patientContainer = null;
public DatabaseHelper() {
    initConnectionPool();
    initDatabase();
    initContainers();
    fillContainers();
}
private void fillContainers() {
	
	
}
private void initContainers() {
	
	try {
        /* TableQuery and SQLContainer for doctor -table */
        TableQuery q1 = new TableQuery("doctor_table", connectionPool);
        doctorContainer = new SQLContainer(q1);
        

        /* TableQuery and SQLContainer for patient -table */
        TableQuery q2 = new TableQuery("patient_table", connectionPool);
        
        patientContainer = new SQLContainer(q2);
    } catch (SQLException e) {
        e.printStackTrace();
    }
  	    
	
}
public Connection initDatabase() {
	Connection conn=null;
	try {
		
		 conn = connectionPool.reserveConnection();
				Statement statement = conn.createStatement();
				
		try {
            statement.executeQuery("SELECT * FROM doctor_table");
            statement.executeQuery("SELECT * FROM patient_table");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		statement.close();
	    conn.commit();
	    connectionPool.releaseConnection(conn);
	    
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return conn;
	
}
public JDBCConnectionPool initConnectionPool() {
	try {
		//String URL =  "jdbc:mysql://mysql-Dpredictor.jelastic.servint.net/dpredictor_db";
		String URL = "jdbc:mysql://localhost:3306/dpredictor_db";
       /*connectionPool = new SimpleJDBCConnectionPool(
        		"com.mysql.jdbc.Driver",
				URL, "root", "v1fT7Acq5H", 2, 5);*/
        connectionPool = new SimpleJDBCConnectionPool(
        		"com.mysql.jdbc.Driver",
				URL, "root", "", 2, 5);
    } catch (SQLException e) {
        e.printStackTrace();
    }
	return connectionPool;
}
public SQLContainer getDoctorContainer() {
    return doctorContainer;
}
public SQLContainer getPatientContainer() {
    return patientContainer;
}

	

}
