package diseasePredictor;

import com.vaadin.addon.charts.Chart;
import com.vaadin.addon.charts.model.ChartType;
import com.vaadin.addon.charts.model.Configuration;
import com.vaadin.addon.charts.model.ListSeries;
import com.vaadin.addon.charts.model.XAxis;
import com.vaadin.addon.charts.model.YAxis;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.ThemeResource;
import com.vaadin.shared.ui.MarginInfo;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.Component;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.Embedded;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.InlineDateField;
import com.vaadin.ui.Notification;
import com.vaadin.ui.TextArea;
import com.vaadin.ui.VerticalLayout;


public class HomePage  extends VerticalLayout implements View {
	/**
	 * Home Page view
	 */
	private static final long serialVersionUID = -4647046019047097255L;
	final DatabaseHelper dbHelp = new DatabaseHelper();
	public String username;

	public HomePage() {
        setSizeFull();
        addStyleName("diseasepredictor-view");
        
        }        
        
    
	@Override
    public void enter(ViewChangeEvent event) {
		this.username = String.valueOf(getSession().getAttribute("user"));
		setSizeFull();
    	homepage();
    }


	private void homepage() {

		HorizontalLayout top=new HorizontalLayout();
		top.setSizeFull();
        Embedded flash = new Embedded(null,new ThemeResource("img/hom.jpg"));
        flash.setWidth("130%");
        top.addComponent(flash);
        top.setComponentAlignment(flash, Alignment.TOP_CENTER);
        
        InlineDateField date = new InlineDateField();
        date.focus();
        top.addComponent(date);
        top.setComponentAlignment(date, Alignment.TOP_RIGHT);
        addComponent(top);
        HorizontalLayout bottom= new HorizontalLayout();

         bottom.setMargin(new MarginInfo(true, true, false, true));
        bottom.setSpacing(true);
        TextArea notes = new TextArea(" My Notes");
        notes.setValue("This is a health prediction and monitoring application.\n.Click the Patient Dashboard to view patient details and edit patient profile\n� Click Run Diagnosis to generate prediction report\n�Click Create Profile to create a new patient profile");
        notes.setSizeFull();
        CssLayout panel = createPanel(notes);
        panel.addStyleName("notes");
        bottom.setSpacing(true);
        bottom.setSizeFull();
        bottom.addComponent(panel);
        
        addComponent(bottom);
        
		
	}
    private CssLayout createPanel(Component content) {
    	CssLayout panel = new CssLayout();
        panel.addStyleName("layout-panel");
        panel.setSizeFull();

        Button configure = new Button();
        configure.addStyleName("configure");
        configure.addStyleName("icon-cog");
        configure.addStyleName("icon-only");
        configure.addStyleName("borderless");
        configure.setDescription("Configure");
        configure.addStyleName("small");
        configure.addClickListener(new ClickListener() {
            /**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
            public void buttonClick(ClickEvent event) {
                Notification.show("Not implemented in this demo");
            }
        });
        //panel.addComponent(configure);

        panel.addComponent(content);
        return panel;
    }
	
}